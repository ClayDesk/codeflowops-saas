#!/usr/bin/env python3
'''
Elastic Beanstalk entry point for CodeFlowOps Backend
'''
import sys
import os
from pathlib import Path

# Add current directory to Python path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

# Import the FastAPI app from main.py
try:
    from main import app as application
    print("CodeFlowOps backend loaded successfully")
except ImportError as e:
    print(f"Failed to import application: {e}")
    # Create a minimal fallback app
    from fastapi import FastAPI
    application = FastAPI(title="CodeFlowOps Backend - Fallback")
    
    @application.get("/")
    async def root():
        return {
            "message": "CodeFlowOps Backend - Fallback Mode",
            "status": "error",
            "error": f"Failed to load main application: {e}"
        }
    
    @application.get("/health")
    async def health():
        return {"status": "unhealthy", "error": str(e)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(application, host="0.0.0.0", port=8000)
