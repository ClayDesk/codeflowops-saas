"""
Stack-specific router system for CodeFlowOps SaaS
Dynamic router loading based on detected stack type
"""
