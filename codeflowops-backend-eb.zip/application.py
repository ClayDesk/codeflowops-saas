#!/usr/bin/env python3
'''
BULLETPROOF Elastic Beanstalk entry point - NO MORE VARIABLE SCOPE ERRORS
'''
import sys
import os
from pathlib import Path

# Add current directory to Python path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

print("Starting CodeFlowOps Backend - BULLETPROOF VERSION")

# Initialize variables at module level to prevent scope errors
application = None
import_error_msg = None

try:
    from main import app as main_app
    application = main_app
    print("SUCCESS: CodeFlowOps Enhanced API loaded")
    print("Enhanced Repository Analyzer: ACTIVE")
    print("Static Site Detection: ENABLED")
    print("Available endpoints:")
    print("  POST /api/analyze-repo - Repository analysis")
    print("  GET /health - Health check")
    
except Exception as import_error:
    import_error_msg = str(import_error)
    print(f"Main import failed: {import_error_msg}")
    
    # Create fallback app with NO scope issues
    from fastapi import FastAPI
    
    fallback_app = FastAPI(title="CodeFlowOps Backend - Fallback")
    
    @fallback_app.get("/")
    async def fallback_root():
        return {
            "message": "CodeFlowOps Backend - Fallback Mode",
            "status": "degraded", 
            "error": import_error_msg,
            "version": "enhanced-analyzer-fallback"
        }
    
    @fallback_app.get("/health")
    async def fallback_health():
        return {
            "status": "degraded", 
            "error": import_error_msg,
            "message": "Running in fallback mode"
        }
    
    application = fallback_app
    print("Fallback mode activated")

# Final safety check
if application is None:
    from fastapi import FastAPI
    application = FastAPI()
    
    @application.get("/")
    async def emergency():
        return {"message": "Emergency mode - application was None"}

print(f"Application ready: {type(application).__name__}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(application, host="0.0.0.0", port=8000)
