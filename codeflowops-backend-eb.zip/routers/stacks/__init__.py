"""
Stack-specific routers module
"""
