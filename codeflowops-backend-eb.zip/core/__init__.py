"""
Core module for CodeFlowOps plugin architecture
"""
