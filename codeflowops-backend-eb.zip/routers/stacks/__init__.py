"""
Stack-specific routers module
"""
