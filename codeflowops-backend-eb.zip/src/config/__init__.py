# Configuration module for CodeFlowOps backend
"""
Configuration module containing various service configurations
"""
