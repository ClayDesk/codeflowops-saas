"""
CodeFlowOps Enhanced Analysis Engine
API Package
"""

__version__ = "1.0.0"
